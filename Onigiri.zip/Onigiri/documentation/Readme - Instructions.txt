If you have extracted the zip file manually you should read this.
If Onigiri is already installed into Blender and functioning just ignore this readme.

- Installation -
This video shows step by step how to install Onigiri.
INSTALL VIDEO LINK

- Join the Discord Server -
If you need further help ask on our discord.

INSERT DISCORD LINK

- Join the group -

This too was made for everyone who wants to rig things for secondlife.
It is covered under GPLv3.




